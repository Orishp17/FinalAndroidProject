package com.example.androidproject.dto


data class UserLoginForm(
    var email: String = "",
    var password: String = "",
)