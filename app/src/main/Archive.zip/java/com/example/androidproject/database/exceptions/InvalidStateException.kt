package com.example.androidproject.database.exceptions

class InvalidStateException(message: String = "Invalid state") : RuntimeException(message)
