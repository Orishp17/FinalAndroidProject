package com.example.androidproject.dto

data class EditProfileData(
    var newName: String? = null,
    var newYearsExperience: Int? = null,
)