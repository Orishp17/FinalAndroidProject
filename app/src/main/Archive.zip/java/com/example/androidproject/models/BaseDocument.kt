package com.example.androidproject.models



abstract class BaseDocument  {
    abstract var id: String
    abstract var updatedAt: Long
}
